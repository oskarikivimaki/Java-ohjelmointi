package com.example;

import java.util.Arrays;

public class Main {
    public static void main(String[] args) {

        Teh1 teh1 = new Teh1();
        Teh2 teh2 = new Teh2();
        Teh3 teh3 = new Teh3();
        Teh4 teh4 = new Teh4();
        Teh5 teh5 = new Teh5();
        Teh6 teh6 = new Teh6();
        Teh7 teh7 = new Teh7();
        Teh8 teh8 = new Teh8();
        Teh9 teh9 = new Teh9();
        Teh10 teh10 = new Teh10();

        // 1
        //System.out.println(teh1.cords(new double[]{0,0}, new double[]{0,3}));

        // 2
        //teh2.tree();
        
        // 3
        //System.out.println(teh3.circle());
        //System.out.println(teh3.square());
        //System.out.println(teh3.rTriangle());

        // 4
        //teh4.matr();

        // 5
        //System.out.println(Arrays.toString(teh5.bubbleSort()));

        // 6
        //System.out.println(teh6.palindrome());

        // 7
        //teh7.fibo();

        //8
        // System.out.println(teh8.prime());

        //9
        // System.out.println(teh9.time());

        //10
        System.out.println(teh10.random());
    }
}
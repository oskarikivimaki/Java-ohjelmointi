package com.example;

public class Teh1 {
    public double cords(double loc1[], double loc2[]){
        return Math.sqrt((Math.pow((loc1[0] - loc2[0]), 2)) + (Math.pow((loc1[1] - loc2[1]), 2)));
    }
}